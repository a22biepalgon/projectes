import sys

num = int(sys.argv[1])
print(num*num)